<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class residenceCountry extends Model
{
    protected $table="residence_country";
}
